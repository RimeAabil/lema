const String GEMINI_API_KEY = "AIzaSyCcL50-awHjVCe-SPRUAA1sqvdbM0NCaMw";
